# Koe — Japanese & Turkish text-to-speech

A small website that converts Japanese or Turkish text into speech you can
download as an MP3. Uses Google Cloud Text-to-Speech (free tier: 1 million
characters per month).

## What you need
- Node.js 18 or newer
- A Google Cloud account (a credit card is required to sign up, but you will
  not be charged within the free tier)

## One-time Google Cloud setup

1. Go to https://console.cloud.google.com and create a new project.
2. In the search bar, find **Cloud Text-to-Speech API** and click **Enable**.
3. Go to **APIs & Services → Credentials → Create credentials → Service account**.
   Give it any name and finish (no roles needed).
4. Click the new service account → **Keys → Add key → Create new key → JSON**.
   A `.json` file downloads. Keep it private — this is your credential.
5. Move that file into this project folder and rename it `key.json`.

## Run it

```bash
npm install

# Point the app at your key file:
#   macOS / Linux:
export GOOGLE_APPLICATION_CREDENTIALS="$PWD/key.json"
#   Windows (PowerShell):
#   $env:GOOGLE_APPLICATION_CREDENTIALS="$PWD\key.json"

npm start
```

Open http://localhost:3000

Type text, pick Japanese or Turkish, click **Generate speech**, then
**Download MP3**.

## Changing the voices

The voices are set in `server.js` (the `VOICES` object). To hear other
options, list all Japanese/Turkish voices with:

```bash
# Japanese
curl -s -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://texttospeech.googleapis.com/v1/voices?languageCode=ja-JP"

# Turkish
curl -s -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://texttospeech.googleapis.com/v1/voices?languageCode=tr-TR"
```

Then swap the `name` field in `server.js`. Names ending in `-Neural2` or
`-Wavenet` sound the most natural (they draw from a smaller free quota than
Standard voices, but still generous).

## Notes
- Never commit `key.json` to a public repo. Add it to `.gitignore`.
- Each request is capped at 5000 characters in `server.js`; raise it if needed.
