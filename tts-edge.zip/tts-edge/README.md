# Koe — Japanese & Turkish text-to-speech

A small website that converts Japanese or Turkish text into speech you can
download as an MP3. Uses **edge-tts** (Microsoft Edge's online neural voices).

**No account. No API key. No credit card.** It just needs an internet
connection, because it talks to Microsoft's public read-aloud service the same
way the Edge browser does.

## What you need
- Python 3.9 or newer
- An internet connection

## Run it

```bash
# 1. Install the two dependencies
pip install -r requirements.txt

# 2. Start the server
python server.py
```

Open http://localhost:5000

Type text, pick Japanese or Turkish, click **Generate speech**, then
**Download MP3**.

## Changing the voices

Voices are set in `server.py` (the `VOICES` dict). To see every available
voice for each language:

```bash
edge-tts --list-voices | grep ja-JP
edge-tts --list-voices | grep tr-TR
```

Good options:
- Japanese: `ja-JP-NanamiNeural` (female), `ja-JP-KeitaNeural` (male)
- Turkish:  `tr-TR-EmelNeural` (female), `tr-TR-AhmetNeural` (male)

Just swap the name in the `VOICES` dict and restart.

## How speed & pitch work
- The **Speed** slider is a multiplier (1.0× = normal). The server converts it
  to the percentage edge-tts expects (1.2× becomes "+20%").
- The **Pitch** slider is in Hz, from -50 to +50.

## Notes
- Each request is capped at 5000 characters in `server.py`; raise `MAX_CHARS`
  if you need more.
- Because it relies on a Microsoft endpoint, it needs to be online. If Microsoft
  ever changes the service the library may need an update (`pip install -U
  edge-tts`).
